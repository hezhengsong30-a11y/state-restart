/* 邮箱注册 / 登录 —— 本地占位实现
 *
 * 说明：当前为纯前端演示版，账号与密码仅保存在本机 localStorage，
 *      密码做了简单哈希（非加密安全）。正式部署时请由后端接管认证。
 *
 * 开发接入后端：只需替换下方 W28_API 中的 register / login / logout / current / resetPassword
 *              五个方法的实现（保持返回 Promise，参数与返回结构不变），界面代码无需改动。
 */
(function(){
'use strict';

var USERS_KEY   = 'women28_users';
var SESSION_KEY = 'women28_session';

/* ---------- localStorage 基础读写 ---------- */
function readUsers(){
  try{ var r=JSON.parse(localStorage.getItem(USERS_KEY)||'[]'); return Array.isArray(r)?r:[]; }catch(e){ return []; }
}
function writeUsers(list){
  try{ localStorage.setItem(USERS_KEY, JSON.stringify(list)); }catch(e){}
}
function readSession(){
  try{ var s=JSON.parse(localStorage.getItem(SESSION_KEY)||'null'); return (s && s.email) ? s : null; }catch(e){ return null; }
}
function writeSession(s){
  try{ s ? localStorage.setItem(SESSION_KEY, JSON.stringify(s)) : localStorage.removeItem(SESSION_KEY); }catch(e){}
}
function normEmail(e){ return String(e||'').trim().toLowerCase(); }
function validEmail(e){ return /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/.test(e); }
/* 占位哈希：仅避免明文存储，不具备真实安全性 */
function hashPwd(pwd){
  var s='w28:'+String(pwd), h=5381;
  for(var i=0;i<s.length;i++){ h=((h<<5)+h) ^ s.charCodeAt(i); }
  return 'p1_'+(h>>>0).toString(36)+'_'+s.length;
}
function fail(msg){ return Promise.reject(new Error(msg)); }

/* ========================================================================
 *  认证接口层（占位实现）—— 开发接入后端时替换此对象
 * ===================================================================== */
var W28_API = {
  register: function(email, password){
    var em=normEmail(email);
    if(!validEmail(em)) return fail('请输入正确的邮箱地址');
    if(String(password).length<6) return fail('密码至少 6 位');
    var users=readUsers();
    if(users.some(function(u){ return u.email===em; })) return fail('该邮箱已注册，请直接登录');
    users.push({ email:em, password:hashPwd(password), createdAt:new Date().toISOString() });
    writeUsers(users);
    return Promise.resolve({ email:em });
  },

  login: function(email, password){
    var em=normEmail(email);
    if(!validEmail(em)) return fail('请输入正确的邮箱地址');
    if(!String(password)) return fail('请输入密码');
    var u=readUsers().filter(function(x){ return x.email===em; })[0];
    if(!u) return fail('该邮箱尚未注册，请先注册');
    if(u.password!==hashPwd(password)) return fail('邮箱或密码不正确');
    return Promise.resolve({ email:em });
  },

  logout: function(){
    writeSession(null);
    return Promise.resolve();
  },

  current: function(){
    return readSession();
  },

  resetPassword: function(){
    return fail('本地演示版暂不支持找回密码，正式部署后由后端提供');
  }
};
/* ===================== 占位实现结束 ===================== */

/* ---------- 界面 ---------- */
var MODE='login';

function template(){
  return ''
  + '<div class="auth-wrap">'
  +   '<section class="auth-side">'
  +     '<div class="auth-logo">🌸</div>'
  +     '<h1>女性养生 · 28 天周期打卡</h1>'
  +     '<p class="auth-sub">按月经周期分 6 个阶段，每天 8 项小事。不追求完美，只记录真实。</p>'
  +     '<ul class="auth-points">'
  +       '<li><span>📅</span>28 天分阶段计划，每天知道做什么</li>'
  +       '<li><span>📈</span>体温、感受、行动趋势一目了然</li>'
  +       '<li><span>🔒</span>数据按账号独立保存在本机</li>'
  +     '</ul>'
  +   '</section>'
  +   '<section class="auth-card">'
  +     '<div class="auth-tabs">'
  +       '<button type="button" class="auth-tab active" data-mode="login">登录</button>'
  +       '<button type="button" class="auth-tab" data-mode="register">注册</button>'
  +     '</div>'
  +     '<form class="auth-form" id="auth-form" novalidate>'
  +       '<label class="auth-field"><span class="auth-label">邮箱</span>'
  +         '<input type="email" id="auth-email" autocomplete="username" placeholder="you@example.com">'
  +       '</label>'
  +       '<label class="auth-field"><span class="auth-label">密码</span>'
  +         '<input type="password" id="auth-pwd" autocomplete="current-password" placeholder="至少 6 位">'
  +       '</label>'
  +       '<label class="auth-field" id="auth-pwd2-field" style="display:none"><span class="auth-label">确认密码</span>'
  +         '<input type="password" id="auth-pwd2" autocomplete="new-password" placeholder="再输入一次">'
  +       '</label>'
  +       '<div class="auth-row">'
  +         '<label class="auth-check"><input type="checkbox" id="auth-show"> 显示密码</label>'
  +         '<a class="auth-link" id="auth-forgot" href="javascript:void 0">忘记密码？</a>'
  +       '</div>'
  +       '<div class="auth-err" id="auth-err"></div>'
  +       '<button class="auth-submit" id="auth-submit" type="submit">登 录</button>'
  +     '</form>'
  +     '<p class="auth-foot">本地演示版：账号与密码仅保存在本机浏览器，正式部署后由后端接管认证。</p>'
  +   '</section>'
  + '</div>';
}

function setMode(mode){
  MODE=mode;
  var scr=document.getElementById('auth-screen');
  scr.querySelectorAll('.auth-tab').forEach(function(b){
    b.classList.toggle('active', b.getAttribute('data-mode')===mode);
  });
  document.getElementById('auth-pwd2-field').style.display = (mode==='register')?'block':'none';
  document.getElementById('auth-submit').textContent = (mode==='register')?'注 册':'登 录';
  document.getElementById('auth-pwd').setAttribute('autocomplete', mode==='register'?'new-password':'current-password');
  setErr('');
}

function setErr(msg){
  var el=document.getElementById('auth-err');
  if(el) el.textContent=msg||'';
}

function showAuth(mode){
  var scr=document.getElementById('auth-screen');
  if(!scr) return;
  document.body.classList.add('auth-mode');
  scr.classList.add('show');
  scr.innerHTML=template();
  setMode(mode||'login');
  bindAuth();
}

function hideAuth(){
  var scr=document.getElementById('auth-screen');
  if(!scr) return;
  scr.classList.remove('show');
  scr.innerHTML='';
  document.body.classList.remove('auth-mode');
}

function afterLogin(email){
  writeSession({ email:email, loginAt:new Date().toISOString() });
  hideAuth();
  if(window.W28App) window.W28App.boot(email);
}

function bindAuth(){
  var scr=document.getElementById('auth-screen');
  scr.querySelectorAll('.auth-tab').forEach(function(b){
    b.addEventListener('click', function(){ setMode(b.getAttribute('data-mode')); });
  });
  var showCb=document.getElementById('auth-show');
  showCb.addEventListener('change', function(){
    ['auth-pwd','auth-pwd2'].forEach(function(id){
      var i=document.getElementById(id); if(i) i.type = showCb.checked ? 'text':'password';
    });
  });
  document.getElementById('auth-forgot').addEventListener('click', function(){
    W28_API.resetPassword().catch(function(err){ setErr(err.message); });
  });
  document.getElementById('auth-form').addEventListener('submit', function(ev){
    ev.preventDefault();
    submit();
  });
}

function submit(){
  var emailEl=document.getElementById('auth-email');
  var pwdEl=document.getElementById('auth-pwd');
  var pwd2El=document.getElementById('auth-pwd2');
  var btn=document.getElementById('auth-submit');
  var email=emailEl.value.trim();
  var pwd=pwdEl.value;

  setErr('');
  if(!email){ setErr('请输入邮箱'); emailEl.focus(); return; }
  if(!validEmail(email)){ setErr('邮箱格式不正确'); emailEl.focus(); return; }
  if(!pwd){ setErr('请输入密码'); pwdEl.focus(); return; }
  if(MODE==='register'){
    if(pwd.length<6){ setErr('密码至少 6 位'); pwdEl.focus(); return; }
    if(pwd!==pwd2El.value){ setErr('两次输入的密码不一致'); pwd2El.focus(); return; }
  }

  btn.disabled=true;
  var action=(MODE==='register')?W28_API.register:W28_API.login;
  action(email,pwd).then(function(res){
    btn.disabled=false;
    afterLogin(res.email);
  }).catch(function(err){
    btn.disabled=false;
    setErr(err.message||'操作失败，请重试');
  });
}

/* 对外暴露：认证接口 + 退出登录 */
window.W28Auth={
  register:function(e,p){ return W28_API.register(e,p); },
  login:function(e,p){ return W28_API.login(e,p); },
  current:function(){ return W28_API.current(); },
  logout:function(){
    W28_API.logout();
    if(window.W28App) window.W28App.unboot();
    showAuth('login');
  }
};

/* 启动：有会话直接进入应用，否则显示登录页 */
function start(){
  var s=W28_API.current();
  if(s && s.email){
    if(window.W28App) window.W28App.boot(s.email);
    else showAuth('login');
  } else {
    showAuth('login');
  }
}
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', start);
else start();

})();
